# Grazioso Salvare – AAC Dashboard  
**Author:** Chris Davidson - CS-340 Project Two

## About the Project:
This Python Dash web-app lets Grazioso Salvare explore the Austin Animal Center (AAC) outcomes collection and quickly identify adoptable dogs that meet different rescue-team profiles (water, mountain, disaster).  

## Key widgets
* **Interactive Data Table** – sort, filter, search, single-row select  
* **Leaflet Map** – pin drops to the selected animal’s found location  
* **Donut Chart** – live outcome-type distribution for current table view  
* **Age-vs-Outcome Scatter** – correlates age (weeks) with outcome types  

All data are pulled **live from MongoDB** through a reusable CRUD module<br>
`animal_shelter.py`—no CSV exports or manual refreshing are required.


## Motivation
Field coordinators asked for a *one-stop* dashboard that
1. displays **all** 10 000 + AAC outcome records,  
2. filters to each rescue profile with **one click**, and  
3. surfaces **location and outcome insights** visually.

Duplicating ad-hoc Mongo queries in every notebook was error-prone, so I wrapped the database access in a tiny, testable module and built the Dash front end on top of it.



## Getting Started

### 1. Clone repo
git clone <your_git_url> cs340_project2 && cd cs340_project2

### 2. Set environment variables *once* per session
export MONGO_USER=root
export MONGO_PASS=iZHac1gYyP
export MONGO_HOST=nv-desktop-services.apporto.com
export MONGO_PORT=31373

### 3. (optional) create / activate virtual environment
python -m venv venv && source venv/bin/activate

### 4. Install dependencies
pip install -r requirements.txt

### 5. Launch the dashboard
jupyter lab dashboard.ipynb

### The Dash app starts at http://127.0.0.1:8050


## Installation:
### MongoDB 6
1. Document store holding *AAC.animals*
2. Provided in Apporto
### PyMongo 4.6
1. Official driver; async-safe & well-maintained
2. `pip install pymongo`
### Dash 2.16 
1. Lightweight web framework for data apps
2. `pip install dash`
### Dash-Leaflet
1. Open-source Mapbox/Leaflet component
2. `pip install dash-leaflet`
### Plotly Express
1. Quick, interactive charts
2. `pip install plotly`


## Usage
from animal_shelter import AnimalShelter

shelter = AnimalShelter(
        user="root",
        password="iZHac1gYyP",
        host="nv-desktop-services.apporto.com",
        port=31373,
        db_name="AAC",
        col_name="animals")

#Example: count all dogs
dogs = shelter.read({"animal_type": "Dog"})
print(len(dogs), "dogs in database")

#Example: wilderness-rescue query (German Shepherd & friends)
query  = {
    "animal_type": "Dog",
    "breed": {
        "$in": [
          "German Shepherd", "Alaskan Malamute",
          "Old English Sheepdog", "Siberian Husky", "Rottweiler"
        ]},
    "sex_upon_outcome": "Intact Male",
    "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}
}
for doc in shelter.read(query, {"_id": 0, "animal_id": 1, "breed": 1}):
    print(doc)


## Tests
The unit tests live in tests/ and are run with pytest:
pytest -q
**Expected output:**
4 passed in 1.15s

test_create.py – verifies a document can be inserted
test_read.py – verifies filtered reads return correct keys
test_update_delete.py – ensures update & delete report correct counts


## Screenshots
Default view  

![Default](http://localhost:4042/view/cs340_project2/screenshots/Dashboard%20-%20default%20view.png)

Filtered by *Bird*  

![Bird filter](http://localhost:4042/view/cs340_project2/screenshots/Dashboard%20-%20filtered%20by%20animal%20type.png)

Mountain-rescue preset  

![Mountain rescue](http://localhost:4042/view/cs340_project2/screenshots/Dashboard%20-%20filtered%20by%20rescue.png)


*For questions, reach me at christopher.davidson@snhu.edu.*